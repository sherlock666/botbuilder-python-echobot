# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from . import adaptive_card_example

__all__ = ["adaptive_card_example"]
