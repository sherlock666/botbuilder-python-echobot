# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .main_dialog import MainDialog

__all__ = ["MainDialog"]
