# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import pytest

from botbuilder.schema import Activity
from botframework.connector.auth import JwtTokenValidation
from botframework.connector.auth import SimpleCredentialProvider
from botframework.connector.auth import EmulatorValidation
from botframework.connector.auth import EnterpriseChannelValidation
from botframework.connector.auth import ChannelValidation
from botframework.connector.auth import ClaimsIdentity
from botframework.connector.auth import MicrosoftAppCredentials
from botframework.connector.auth import GovernmentConstants
from botframework.connector.auth import GovernmentChannelValidation


async def jwt_token_validation_validate_auth_header_with_channel_service_succeeds(
    app_id: str, pwd: str, channel_service: str, header: str = None
):
    if header is None:
        header = f"Bearer {MicrosoftAppCredentials(app_id, pwd).get_access_token()}"

    credentials = SimpleCredentialProvider(app_id, pwd)
    result = await JwtTokenValidation.validate_auth_header(
        header, credentials, channel_service, "", "https://webchat.botframework.com/"
    )

    assert result.is_authenticated


class TestAuth:
    EmulatorValidation.TO_BOT_FROM_EMULATOR_TOKEN_VALIDATION_PARAMETERS.ignore_expiration = (
        True
    )
    ChannelValidation.TO_BOT_FROM_CHANNEL_TOKEN_VALIDATION_PARAMETERS.ignore_expiration = (
        True
    )

    @pytest.mark.asyncio
    async def test_connector_auth_header_correct_app_id_and_service_url_should_validate(
        self,
    ):
        header = (
            "Bearer "
            + MicrosoftAppCredentials(
                "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
            ).get_access_token()
        )
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", ""
        )
        result = await JwtTokenValidation.validate_auth_header(
            header, credentials, "", "https://webchat.botframework.com/"
        )

        assert result

    @pytest.mark.asyncio
    async def test_connector_auth_header_with_different_bot_app_id_should_not_validate(
        self,
    ):
        header = (
            "Bearer "
            + MicrosoftAppCredentials(
                "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
            ).get_access_token()
        )
        credentials = SimpleCredentialProvider(
            "00000000-0000-0000-0000-000000000000", ""
        )
        with pytest.raises(Exception) as excinfo:
            await JwtTokenValidation.validate_auth_header(
                header, credentials, "", "https://webchat.botframework.com/"
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_connector_auth_header_and_no_credential_should_not_validate(self):
        header = (
            "Bearer "
            + MicrosoftAppCredentials(
                "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
            ).get_access_token()
        )
        credentials = SimpleCredentialProvider("", "")
        with pytest.raises(Exception) as excinfo:
            await JwtTokenValidation.validate_auth_header(
                header, credentials, "", "https://webchat.botframework.com/"
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_empty_header_and_no_credential_should_throw(self):
        header = ""
        credentials = SimpleCredentialProvider("", "")
        with pytest.raises(Exception) as excinfo:
            await JwtTokenValidation.validate_auth_header(header, credentials, "", None)
        assert "auth_header" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_emulator_msa_header_correct_app_id_and_service_url_should_validate(
        self,
    ):
        header = (
            "Bearer "
            + MicrosoftAppCredentials(
                "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
            ).get_access_token()
        )
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", ""
        )
        result = await JwtTokenValidation.validate_auth_header(
            header, credentials, "", "https://webchat.botframework.com/"
        )

        assert result

    @pytest.mark.asyncio
    async def test_emulator_msa_header_and_no_credential_should_not_validate(self):
        header = (
            "Bearer "
            + MicrosoftAppCredentials(
                "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
            ).get_access_token()
        )
        credentials = SimpleCredentialProvider(
            "00000000-0000-0000-0000-000000000000", ""
        )
        with pytest.raises(Exception) as excinfo:
            await JwtTokenValidation.validate_auth_header(header, credentials, "", None)
            assert "Unauthorized" in excinfo

    # Tests with a valid Token and service url; and ensures that Service url is added to Trusted service url list.
    @pytest.mark.asyncio
    async def test_channel_msa_header_valid_service_url_should_be_trusted(self):
        activity = Activity(
            service_url="https://smba.trafficmanager.net/amer-client-ss.msg/"
        )
        header = (
            "Bearer "
            + MicrosoftAppCredentials(
                "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
            ).get_access_token()
        )
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", ""
        )

        await JwtTokenValidation.authenticate_request(activity, header, credentials)

        assert MicrosoftAppCredentials.is_trusted_service(
            "https://smba.trafficmanager.net/amer-client-ss.msg/"
        )

    @pytest.mark.asyncio
    # Tests with a valid Token and invalid service url and ensures that Service url is NOT added to
    # Trusted service url list.
    async def test_channel_msa_header_invalid_service_url_should_not_be_trusted(self):
        activity = Activity(service_url="https://webchat.botframework.com/")
        header = (
            "Bearer "
            + MicrosoftAppCredentials(
                "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
            ).get_access_token()
        )
        credentials = SimpleCredentialProvider(
            "7f74513e-6f96-4dbc-be9d-9a81fea22b88", ""
        )

        with pytest.raises(Exception) as excinfo:
            await JwtTokenValidation.authenticate_request(activity, header, credentials)
        assert "Unauthorized" in str(excinfo.value)

        assert not MicrosoftAppCredentials.is_trusted_service(
            "https://webchat.botframework.com/"
        )

    @pytest.mark.asyncio
    async def test_channel_msa_header_from_user_specified_tenant(self):
        activity = Activity(
            service_url="https://smba.trafficmanager.net/amer-client-ss.msg/"
        )
        header = "Bearer " + MicrosoftAppCredentials(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F", "microsoft.com"
        ).get_access_token(True)
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", ""
        )

        claims = await JwtTokenValidation.authenticate_request(
            activity, header, credentials
        )

        assert claims.get_claim_value("tid") == "72f988bf-86f1-41af-91ab-2d7cd011db47"

    @pytest.mark.asyncio
    # Tests with no authentication header and makes sure the service URL is not added to the trusted list.
    async def test_channel_authentication_disabled_should_be_anonymous(self):
        activity = Activity(service_url="https://webchat.botframework.com/")
        header = ""
        credentials = SimpleCredentialProvider("", "")

        claims_principal = await JwtTokenValidation.authenticate_request(
            activity, header, credentials
        )

        assert claims_principal.is_authenticated
        assert not claims_principal.claims

    @pytest.mark.asyncio
    # Tests with no authentication header and makes sure the service URL is not added to the trusted list.
    async def test_channel_authentication_disabled_service_url_should_not_be_trusted(
        self,
    ):
        activity = Activity(service_url="https://webchat.botframework.com/")
        header = ""
        credentials = SimpleCredentialProvider("", "")

        await JwtTokenValidation.authenticate_request(activity, header, credentials)

        assert not MicrosoftAppCredentials.is_trusted_service(
            "https://webchat.botframework.com/"
        )

    @pytest.mark.asyncio
    async def test_emulator_auth_header_correct_app_id_and_service_url_with_gov_channel_service_should_validate(
        self,
    ):
        await jwt_token_validation_validate_auth_header_with_channel_service_succeeds(
            "2cd87869-38a0-4182-9251-d056e8f0ac24",  # emulator creds
            "2.30Vs3VQLKt974F",
            GovernmentConstants.CHANNEL_SERVICE,
        )

    @pytest.mark.asyncio
    async def test_emulator_auth_header_correct_app_id_and_service_url_with_private_channel_service_should_validate(
        self,
    ):
        await jwt_token_validation_validate_auth_header_with_channel_service_succeeds(
            "2cd87869-38a0-4182-9251-d056e8f0ac24",  # emulator creds
            "2.30Vs3VQLKt974F",
            "TheChannel",
        )

    @pytest.mark.asyncio
    async def test_government_channel_validation_succeeds(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )

        await GovernmentChannelValidation.validate_identity(
            ClaimsIdentity(
                {"iss": "https://api.botframework.us", "aud": credentials.app_id}, True
            ),
            credentials,
        )

    @pytest.mark.asyncio
    async def test_government_channel_validation_no_authentication_fails(self):
        with pytest.raises(Exception) as excinfo:
            await GovernmentChannelValidation.validate_identity(
                ClaimsIdentity({}, False), None
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_government_channel_validation_no_issuer_fails(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )
        with pytest.raises(Exception) as excinfo:
            await GovernmentChannelValidation.validate_identity(
                ClaimsIdentity({"peanut": "peanut"}, True), credentials
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_government_channel_validation_wrong_issuer_fails(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )
        with pytest.raises(Exception) as excinfo:
            await GovernmentChannelValidation.validate_identity(
                ClaimsIdentity({"iss": "peanut"}, True), credentials
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_government_channel_validation_no_audience_fails(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )
        with pytest.raises(Exception) as excinfo:
            await GovernmentChannelValidation.validate_identity(
                ClaimsIdentity({"iss": "https://api.botframework.us"}, True),
                credentials,
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_government_channel_validation_wrong_audience_fails(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )
        with pytest.raises(Exception) as excinfo:
            await GovernmentChannelValidation.validate_identity(
                ClaimsIdentity(
                    {"iss": "https://api.botframework.us", "aud": "peanut"}, True
                ),
                credentials,
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_enterprise_channel_validation_succeeds(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )

        await EnterpriseChannelValidation.validate_identity(
            ClaimsIdentity(
                {"iss": "https://api.botframework.com", "aud": credentials.app_id}, True
            ),
            credentials,
        )

    @pytest.mark.asyncio
    async def test_enterprise_channel_validation_no_authentication_fails(self):
        with pytest.raises(Exception) as excinfo:
            await EnterpriseChannelValidation.validate_identity(
                ClaimsIdentity({}, False), None
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_enterprise_channel_validation_no_issuer_fails(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )
        with pytest.raises(Exception) as excinfo:
            await EnterpriseChannelValidation.validate_identity(
                ClaimsIdentity({"peanut": "peanut"}, True), credentials
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_enterprise_channel_validation_wrong_issuer_fails(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )
        with pytest.raises(Exception) as excinfo:
            await EnterpriseChannelValidation.validate_identity(
                ClaimsIdentity({"iss": "peanut"}, True), credentials
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_enterprise_channel_validation_no_audience_fails(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )
        with pytest.raises(Exception) as excinfo:
            await GovernmentChannelValidation.validate_identity(
                ClaimsIdentity({"iss": "https://api.botframework.com"}, True),
                credentials,
            )
        assert "Unauthorized" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_enterprise_channel_validation_wrong_audience_fails(self):
        credentials = SimpleCredentialProvider(
            "2cd87869-38a0-4182-9251-d056e8f0ac24", "2.30Vs3VQLKt974F"
        )
        with pytest.raises(Exception) as excinfo:
            await GovernmentChannelValidation.validate_identity(
                ClaimsIdentity(
                    {"iss": "https://api.botframework.com", "aud": "peanut"}, True
                ),
                credentials,
            )
        assert "Unauthorized" in str(excinfo.value)
