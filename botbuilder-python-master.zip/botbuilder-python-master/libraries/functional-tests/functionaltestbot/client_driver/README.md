# Client Driver for Function E2E test

This contains the client code that drives the bot functional test.

It performs simple operations against the bot and validates results.