curl -X POST --header 'Accept: application/json' -d '{"text": "Hi!"}' http://localhost:3979
